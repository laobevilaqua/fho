#ifndef Menu_H

#define Menu_H

/* declaracoes das funcoes */
void showMenu(void (*)(int *));

#endif
