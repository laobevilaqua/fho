#ifndef File_Control_H

#define File_Control_H
/* declaracoes das funcoes de lista */
void getDataFile(char *, void (*)(FILE *, int));

#endif
