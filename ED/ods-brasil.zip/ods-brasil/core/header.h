#ifndef Main_H

#define Main_H
// variaveis

/* declaracoes das funcoes da BST*/
void selectedOptionMenu(int);
void getDataAndOrder();
void buildBST(FILE *, int); 
void pesquisarValorDoEstado();
void excluirEstado();
void pesquisarMediaDoAno();
#endif
